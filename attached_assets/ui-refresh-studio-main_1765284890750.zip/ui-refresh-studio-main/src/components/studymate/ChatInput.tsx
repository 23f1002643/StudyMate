import { useState, KeyboardEvent } from 'react';
import { Send, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';

interface ChatInputProps {
  onSend: (message: string) => void;
  disabled?: boolean;
}

export function ChatInput({ onSend, disabled }: ChatInputProps) {
  const [message, setMessage] = useState('');

  const handleSend = () => {
    if (message.trim() && !disabled) {
      onSend(message.trim());
      setMessage('');
    }
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="p-4 border-t border-border bg-card/50 backdrop-blur-sm">
      <div className="flex items-end gap-3 max-w-4xl mx-auto">
        <div className="relative flex-1">
          <Textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask StudyMate anything..."
            className={cn(
              'min-h-[52px] max-h-32 resize-none pr-12 rounded-xl border-2',
              'focus:border-primary focus:ring-0 transition-colors',
              'placeholder:text-muted-foreground/60'
            )}
            disabled={disabled}
          />
          <div className="absolute right-3 bottom-3 flex items-center gap-1">
            <Sparkles className="h-4 w-4 text-primary/50 animate-pulse-soft" />
          </div>
        </div>
        
        <Button
          onClick={handleSend}
          disabled={!message.trim() || disabled}
          className={cn(
            'h-[52px] w-[52px] rounded-xl gradient-primary shadow-lg',
            'hover:shadow-xl transition-all duration-200 hover:scale-105',
            'disabled:opacity-50 disabled:hover:scale-100'
          )}
        >
          <Send className="h-5 w-5 text-white" />
        </Button>
      </div>
      
      <p className="text-center text-[10px] text-muted-foreground mt-3">
        Press Enter to send, Shift + Enter for new line
      </p>
    </div>
  );
}
